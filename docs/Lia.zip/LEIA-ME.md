# Kit de projeto novo

Para quando você criar a próxima ferramenta da marca Lia.

## Qual pasta usar

| O app roda onde | Use |
|---|---|
| Windows, entregue como `.exe` | **`APP-WINDOWS/`** |
| Celular (Android/iOS) ou navegador | **`APP-MOBILE-OU-WEB/`** |
| Os dois | comece pelo mobile/web e leia a seção 2 do padrão de Windows para a parte desktop |

## O que fazer

1. Copie o conteúdo de `arquivos-prontos/` para o repositório novo, nos lugares
   indicados em `arquivos-prontos/ONDE-VAI-CADA-ARQUIVO.md`.
2. Copie `GUIA-APP-NOVO.md` e o padrão da pasta escolhida para `docs/guia-externo/`
   no repositório novo.
3. Preencha tudo que estiver entre `<` e `>`.
4. Primeiro commit já com `.claude/` no `.gitignore`.
5. Diga à sessão: *"leia `docs/guia-externo/` antes de qualquer trabalho"*.

A partir daí a sessão já começa sabendo as regras da marca, em vez de você explicar
tudo de novo a cada projeto.

## Qualquer agente, não só o Claude Code

Os arquivos usam o Claude Code como exemplo porque é o que você usa. Para outra
ferramenta, só o nome muda: `CLAUDE.md` → `AGENTS.md` (padrão aberto) ou `.cursor/rules`;
`.claude/skills/` → `.agents/skills/`, que já é o caminho neutro.

Duas coisas valem a pena dizer ao agente logo na primeira mensagem, porque ele não tem
como adivinhar:

- **se ele roda na sua máquina ou só tem o repositório** — isso define se ele pode rodar
  PowerShell e testar, ou se o máximo honesto dele é *"escrito, não executado"*;
- **que ele avise quando um mecanismo não existir na ferramenta dele**, em vez de
  improvisar um equivalente em silêncio.

## O que tem em cada pasta

| Arquivo | O que é |
|---|---|
| `GUIA-APP-NOVO.md` | as sete regras da marca, checklist de dia 0, contrato da conexão com a Waifu |
| `PADRAO-DA-MARCA.md` / `PADRAO-MOBILE-WEB.md` | dependências, entrega, onde cada arquivo é salvo, descoberta entre apps |
| `arquivos-prontos/` | arquivos pra copiar e preencher: `CLAUDE.md`, `AGENTS.md`, `memory-bank/`, exemplo de skill, trecho de `.gitignore` |
| `GLOSSARIO.md` | as palavras que têm dois sentidos neste projeto. Leia antes de nomear pasta |
