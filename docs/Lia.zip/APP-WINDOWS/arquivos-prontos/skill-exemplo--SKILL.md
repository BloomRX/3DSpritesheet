---
name: <nome-em-minusculas-com-hifen>
description: <O que faz, em 3ª pessoa.> Use quando <gatilho concreto e observável>. Não use para <caso vizinho>, que é a skill <outra>.
---

# <Título legível>

> As regras mais importantes vão **no topo**. Depois de autocompactação, só os primeiros
> ~5.000 tokens de cada skill são reanexados.

## Quando usar

-

## Quando NÃO usar

- `<caso>` → skill `<outra>`

## O que ler primeiro

- `<arquivo>` — `<por quê>`

## Processo

1.
2.

## Saída esperada

`<formato exato que esta skill deve produzir>`

## Limites

- O que esta skill **não** faz:
- O que ela nunca modifica:

---

<!--
REGRAS DO FORMATO — apague este bloco depois de preencher.

* A pasta precisa ter exatamente o mesmo nome do campo `name`.
* Profundidade de 1 nível: `.agents/skills/<name>/SKILL.md`. Solto não é encontrado.
* `name`: minúsculas com hífen, até 64 caracteres.
* `description`: até 1024 caracteres. É o ÚNICO texto que fica no contexto o tempo todo
  (30 a 100 tokens). O corpo só carrega depois que a descrição casou — por isso ela não
  descreve, ela DISPARA. Descrição vaga é a causa nº 1 de skill que nunca ativa.
* Campos extras úteis: `paths` (globs que limitam a ativação), `allowed-tools`,
  `context: fork` (roda em subagente isolado).
* Corpo abaixo de 500 linhas.
* YAML inválido = falha silenciosa: a skill simplesmente não aparece em /skills.
* Skill só é descoberta na inicialização. Editou? Reinicie o Claude Code.
-->
