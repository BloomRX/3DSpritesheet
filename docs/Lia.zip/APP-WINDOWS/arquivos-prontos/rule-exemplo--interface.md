---
paths:
  - "ui/**/*.py"
---

# Regras de interface

- Nenhuma janela abre sem estado de carregando, de vazio e de erro.
- Mensagem de erro diz o que fazer, nunca só o que falhou.
- Texto na tela em pt-BR. Nada de termo técnico em inglês para o usuário final.

<!--
COMO ISSO FUNCIONA

Arquivo em `.claude/rules/`. Com `paths:` no topo, ele entra no contexto SO quando o
agente mexe num arquivo que casa com o filtro. Sem `paths:`, carrega sempre — igual a
ter escrito no CLAUDE.md.

Tres armadilhas:

1. YAML quebrado falha ABRINDO. Se o bloco entre --- nao for YAML valido, o filtro e
   ignorado e a regra passa a carregar em TUDO. Glob que comeca com * ou { precisa de
   aspas, senao nao e YAML valido.
2. Isto NAO substitui o CLAUDE.md. Regra que precisa valer antes de o agente tocar em
   qualquer arquivo (o que NAO fazer, o que exige autorizacao) fica no CLAUDE.md. Aqui
   vai o detalhe de execucao de uma area.
3. Fatiar o CLAUDE.md em @import NAO economiza contexto — arquivo importado carrega na
   inicializacao do mesmo jeito. So `paths:` economiza.

Para conferir se carregou: /context na sessao, secao "Memory files".
-->
