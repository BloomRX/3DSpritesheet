# Onde vai cada arquivo

Copie para o repositório novo nestes lugares:

| Arquivo pronto | Vai para | Observação |
|---|---|---|
| `CLAUDE.md` | raiz | **uma página.** Passou de duas, virou skill |
| `AGENTS.md` | raiz | **cópia literal do `CLAUDE.md`.** Mudou um, mude o outro |
| `gitignore-acrescentar.txt` | colar no fim do `.gitignore` | **no primeiro commit** |
| `memory-bank--estado.md` | `memory-bank/estado.md` | |
| `memory-bank--padroes.md` | `memory-bank/padroes.md` | é daqui que o `test-runner` tira o comando |
| `memory-bank--decisoes.md` | `memory-bank/decisoes.md` | |
| `skill-exemplo--SKILL.md` | `.agents/skills/<nome>/SKILL.md` | a pasta precisa ter o mesmo nome do campo `name` |
| `rule-exemplo--interface.md` | `.claude/rules/interface.md` | **vai pro git.** Com `paths:`, carrega só na área dele |

Preencha tudo entre `<` e `>`.

---

## Três detalhes que mordem

### 1. `CLAUDE.md` e `AGENTS.md` ao mesmo tempo

Desde a v2.1.277 o Claude Code lê `AGENTS.md` sozinho — **mas só se não existir nenhum
`CLAUDE.md` na pasta aberta nem acima dela.** Existindo os dois, ele lê o `CLAUDE.md` e
ignora o `AGENTS.md`.

Por isso o modelo faz assim: **o mesmo texto literal nos dois arquivos.** O Claude lê o
`CLAUDE.md`; o Codex, o Cursor e o Copilot leem o `AGENTS.md`. Os dois recebem as regras
inteiras.

**Não troque isso por um ponteiro.** "As regras estão no outro arquivo" é texto comum — o
agente pode simplesmente não abrir. Um repositório da marca já perdeu as regras assim.

**E não troque por `@AGENTS.md` na primeira linha.** Esse import só expande quando a
sessão é aberta exatamente naquela pasta. Carregado de uma pasta acima, o texto entra e o
import é pulado **em silêncio**.

Mudou um, mude o outro. É o preço de funcionar em mais de uma ferramenta.

### 2. O junction é metade sua

| Quem | O quê |
|---|---|
| a sessão, por git | `.gitignore` com `.claude/`, criar `.agents/skills/` |
| **você**, na máquina | `New-Item -ItemType Junction -Path ".claude\skills" -Target ".agents\skills"` e **reiniciar o Claude Code** |

Skill só é descoberta na inicialização. E o `.gitignore` vem **antes** do junction: o Git
no Windows enxerga junction como pasta comum e commitaria tudo duplicado.

### 3. `.claude/rules/` vai pro git — `.claude/skills/` não

O `.gitignore` do kit ignora **só** `.claude/skills/` (espelho do junction),
`.claude/worktrees/` e `.claude/settings.local.json`.

Se você ignorar `.claude/` inteiro, as regras de projeto param de ser versionadas e
ninguém mais recebe elas. É um erro silencioso: funciona na sua máquina e em nenhuma outra.
