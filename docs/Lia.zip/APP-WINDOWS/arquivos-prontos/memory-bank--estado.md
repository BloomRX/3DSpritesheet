# Estado atual — <APP>

> **Fonte de verdade operacional.** Toda sessão lê isto antes de trabalhar.
> Registra **estado**, não narrativa — relato longo de rodada vai para `docs/`.

Atualizado em: `<data>`

## Onde estamos

| Item | Valor |
|---|---|
| Branch de trabalho | |
| Último commit validado na plataforma-alvo | |
| Fase | |

## Pronto e verificado na plataforma-alvo

-

## Escrito mas **não** executado na plataforma-alvo

-

## Bloqueios abertos

| O quê | Desde | O que destrava |
|---|---|---|
| | | |

## Próximo passo verificável

1.

---

## Como manter este arquivo

Atualizar **no mesmo commit** quando mudar: a branch, o último commit validado, uma
decisão de produto com efeito visível, ou a fase do roadmap.

Commit que só mexe em documentação **não** precisa tocar aqui. Não registrar o tip da
branch: nasceria obsoleto no commit seguinte — verifique com `git rev-parse HEAD`.
