# Padrões — <APP>

O que o agente precisa saber para não perguntar duas vezes.

## Comando de teste

> O subagent `test-runner` tira o comando **daqui**. Suíte estreita no dia a dia, completa
> só antes de publicar.

| Mexeu em | Rode |
|---|---|
| `<pasta>` | `<comando>` |
| antes de publicar | `<comando completo>` |

## O que conta como prova de que funciona

- **Conta:** `<ex.: execução real no Windows, com print ou log>`
- **Não conta:** teste automatizado verde, revisão de código, "parece certo".

## Convenções

- Nomes:
- Estrutura de pasta:
- Mensagem de commit:
- Idioma de código e comentário:

## Armadilhas já pagas

| Sintoma | Causa | Conserto |
|---|---|---|
| | | |
