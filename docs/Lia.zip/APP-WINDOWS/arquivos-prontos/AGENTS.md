# <NOME DO APP> — instruções do agente

> **Este arquivo é cópia literal do `CLAUDE.md`.** Ferramentas que leem `AGENTS.md`
> (Codex, Cursor, Gemini CLI, Copilot) precisam do conteúdo **aqui dentro**. Um ponteiro
> dizendo "as regras estão no CLAUDE.md" não carrega nada — é texto comum, e o agente
> pode simplesmente não abrir o outro arquivo.
>
> **Mudou um, mude o outro.** São dois arquivos com o mesmo texto de propósito.

<uma linha dizendo o que este app é>

## Antes de qualquer trabalho

Leia `memory-bank/estado.md`. Ele diz onde o projeto parou, o que está validado e o que
está bloqueado. Não parta de pressuposto próprio.

## Stack (decidida — não trocar sem autorização)

- Linguagem/runtime: `<ex.: Python 3.9+>`
- Dependências: **núcleo sem pacote externo**; shell, adaptadores e build podem usar, com
  versão fixa e registro no `THIRD_PARTY_NOTICES.md`
- Alvo: **Windows**, entregue como `.exe` com instalação por usuário (sem admin)

## Regras duras

- Responder em **pt-BR**.
- Nunca `git reset --hard`, `restore`, `clean`, `stash`, `rebase`, `--amend` ou force
  push. Nunca descartar trabalho preexistente.
- **Nunca declarar PASS sem ter executado.** Teste automatizado verde não é PASS de
  runtime — o portão é a plataforma-alvo real.
- Nunca gravar segredo em log, configuração versionada, evidência ou interface.
- Provedor, modelo e endereço de servidor **nunca fixos no código**.
- Não afirmar que algo funciona em plataforma que você não executou. O máximo honesto é
  *"escrito, não executado"*.
- **STOP AND REPORT** em vez de contornar bloqueio, alargar escopo ou commitar remendo.

## Fronteiras deste projeto

- **O usuário final nunca roda `pip`, nunca precisa de Python instalado, nunca vê erro de
  dependência.** O instalador entrega pronto.
- **Todo caminho de arquivo sai de um módulo só** (`caminhos.py`), que detecta se está
  empacotado ou rodando do fonte. Nenhum outro módulo monta caminho na mão.
- As pastas de dados são **idênticas** rodando do repositório ou do `.exe`.
- O app **nunca** presume estar dentro de um checkout git em tempo de execução.
- Nunca escrever em `C:\Program Files\`.
- `<pastas que o agente não deve tocar>`

## Verificação

- Teste: `<comando>`
- Diagnóstico: `<app> --diagnostico` — imprime cada caminho resolvido, a fonte que decidiu
  e ✓/✗ de existência

A build e o teste na plataforma-alvo são do Dev. Você entrega código e diz o que falta
verificar.

## Onde está o resto

- **Convenção de uma área só:** `.claude/rules/` — arquivo com `paths:` no topo entra no
  contexto só quando o agente mexe num arquivo que casa com o filtro.
- **Procedimento por assunto:** `.agents/skills/` — não duplique aqui.
- **Estado atual:** `memory-bank/estado.md`
- **Comandos e convenções:** `memory-bank/padroes.md`
- **Decisões e descartes:** `memory-bank/decisoes.md`

> Se este arquivo passar de duas páginas, alguma coisa aqui é skill.
