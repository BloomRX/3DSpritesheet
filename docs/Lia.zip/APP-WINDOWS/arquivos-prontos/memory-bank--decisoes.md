# Decisões — <APP>

Uma linha por decisão. **Rótulo obrigatório.**

`confirmado` · `proposto` · `suposição` · `em aberto`

| # | Decisão | Rótulo | Data | Por quê | O que foi descartado |
|---|---|---|---|---|---|
| 1 | | | | | |

---

## Decisões que já valem para todo app da marca

| Decisão | Rótulo |
|---|---|
| Código próprio em MIT; nome, personagem e identidade visual fora da MIT | `confirmado` |
| Nenhum provedor, modelo ou runtime fixo no código — o usuário digita um endereço | `confirmado` |
| Nunca embarcar chave de API do Dev no produto | `confirmado` |
| O app funciona com a Lia Waifu ausente | `confirmado` |
| Conversa com a Lia **não** é autorização para gravar, executar ou gastar | `confirmado` |

> **Suposição não vira confirmado por tempo.** Só o Dev confirma.
